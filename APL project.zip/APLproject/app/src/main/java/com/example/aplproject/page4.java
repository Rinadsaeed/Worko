package com.example.aplproject;
import android.support.v7.app.AppCompatActivity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;



public class page4 extends AppCompatActivity {

    Button button5;
    EditText editTextbudget1;

    private Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page4);

        button5 = findViewById(R.id.button5);
        editTextbudget1 = findViewById(R.id.editTextbudget1);

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x = editTextbudget1.getText().toString();

                if (Integer.parseInt(x) >= 20000 && Integer.parseInt(x) <= 100000) {
                    Intent intent = new Intent(getBaseContext(), ha1.class);
                    startActivity(intent);
                } else if (Integer.parseInt(x) >= 5000 && Integer.parseInt(x) <= 10000) {
                    Intent intent = new Intent(getBaseContext(), ha2.class);
                    startActivity(intent);
                } else if (Integer.parseInt(x) >= 1000 && Integer.parseInt(x) <= 5000) {
                    Intent intent = new Intent(getBaseContext(), ha3.class);
                    startActivity(intent);
                } else if (Integer.parseInt(x) >= 500 && Integer.parseInt(x) <= 1000) {
                    Intent intent = new Intent(getBaseContext(), ha4.class);
                    startActivity(intent);
                } else if (Integer.parseInt(x) < 500) {
                    dialog = new Dialog(page4.this);
                    dialog.setContentView(R.layout.custom_dialog);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.background));
                    }
                    dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    dialog.setCancelable(false); //Optional
                    dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation; //Setting the animations to dialog

                    Button Okay = dialog.findViewById(R.id.btn_okay);

                    Okay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(page4.this, page4.class);
                            startActivity(intent);
                        }
                    });

                    dialog.show(); // Showing the dialog here
                }
            }
        });
    }
}

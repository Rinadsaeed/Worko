package com.example.aplproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.content.Intent;

public class page2 extends AppCompatActivity {
    Button Hand_btn;
    Button sale_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
        Hand_btn =findViewById(R.id.button2);
        Hand_btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), page4.class);

                startActivity(intent);
            }

        });

        sale_btn =findViewById(R.id.sale_btn);
        sale_btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), budget2.class);

                startActivity(intent);
            }

        });

    }
}

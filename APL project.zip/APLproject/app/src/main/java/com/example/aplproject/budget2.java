package com.example.aplproject;

import android.support.v7.app.AppCompatActivity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class budget2 extends AppCompatActivity {

    Button button6;
    EditText editTextbudget2;

    private Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget2);

        button6 = findViewById(R.id.button4);
        editTextbudget2 = findViewById(R.id.editTextbudget2);

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String x = editTextbudget2.getText().toString();

                if (Integer.parseInt(x) >= 20000 && Integer.parseInt(x) <= 100000) {
                    Intent intent = new Intent(getBaseContext(), sa1.class);
                    startActivity(intent);
                }
                else if (Integer.parseInt(x) >= 5000 && Integer.parseInt(x) <= 10000) {
                    Intent intent = new Intent(getBaseContext(), sa2.class);
                    startActivity(intent);
                }
                else if (Integer.parseInt(x) >= 1000 && Integer.parseInt(x) <= 5000) {
                    Intent intent = new Intent(getBaseContext(), sa3.class);
                    startActivity(intent);
                }
                else if (Integer.parseInt(x) >= 500 && Integer.parseInt(x) <= 1000) {
                    Intent intent = new Intent(getBaseContext(), sa4.class);
                    startActivity(intent);
                }
                else if (Integer.parseInt(x) < 500) {
                    dialog = new Dialog(budget2.this);
                    dialog.setContentView(R.layout.custom_dialog);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.background));
                    }
                    dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    dialog.setCancelable(false); //Optional
                    dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation; //Setting the animations to dialog

                    Button Okay = dialog.findViewById(R.id.btn_okay);

                    Okay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(budget2.this, budget2.class);
                            startActivity(intent);
                        }
                    });

                    dialog.show(); // Showing the dialog here

                }
            }
        });
    }
}
package com.example.aplproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class ha1 extends AppCompatActivity {

   Button back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ha1);

       back =findViewById(R.id.back);
       back.setOnClickListener(new View.OnClickListener(){
            @Override
          public void onClick(View view) {
               Intent intent = new Intent(getBaseContext(), page4.class);
                startActivity(intent);
            }});

        ImageView imageView = findViewById(R.id.imageView1);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to start the new activity
                Intent intent = new Intent(ha1.this, signUp.class);
                startActivity(intent);
            }
        });

    }
}
